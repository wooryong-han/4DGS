package com.artimesia.dynamometer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.ListIterator;

/**
 * solver2
 * 측정 위치 기준
 * 손가락별 연속적인 데이터 합
 * 손가락별 평균, 분산, 표준편차
 */

public class Solver2 {
    private Parameter2 parameter2;

    private ArrayList<GripStrength> gripStrengthList;

    private String finger; //손가락 지정
    private String user; //사용자 이름
    private String hand; //좌,우
    private String mobile; //핸폰

    /**
     * 최대 악력점(Point)
     * Max Voltage
     */
    GripStrength maxGripStrengthPoint;

    /**
     *  10% 시작 악력점(Point)
     */
    GripStrength tenGripStrengthStartPoint;

    /**
     *  10% 악력값(Scalar)
     *  10% Max Out Valtage
     */
    double tenGripStrengthValue;

    /**
     *  10% 종료 악력점(Point)
     */
    GripStrength tenGripStrengthEndPoint;

    /**
     *  평균 악력값(Scalar)
     *  Average Voltage between 10% Max and 90% Max
     *  10% 시작 악력점(Point)와 90% 시작 악력점(Point) 구간의 평균값을 산정
     */
    double averageGripStrengthValue;

    /**
     *  연속적인 누적합
     *  10% 시작 악력점(Point)에서 10% 종료까지 악력값
     *  분산/표준편차
     */
    double cumlativeSumValue = 0.0;

    /**
     *  분산/표준편차
     */
    double varianGripStrengthValue = 0.0;       //분산
    double sdGripStrengthValue = 0.0;           //표준편차

    public Solver2(String name, ArrayList<GripStrength> gripStrengthList, String user, String hand, String mobile, Parameter2 parameter) {
        // 손가락 지정
        this.finger = name;
        // 악력값 리스트 받기
        this.gripStrengthList = gripStrengthList;

        this.user = user;
        this.hand = hand;
        this.mobile = mobile;
        this.parameter2 = parameter;
    }

    public boolean analyse() {
        ListIterator<GripStrength> iterator;
        iterator = gripStrengthList.listIterator();

        /**
         * 최대 악력점(Point) 구하기
         * Max Voltage
         */
        while (iterator.hasNext()) {
            GripStrength tempGripStrength = iterator.next();
            if(tempGripStrength.getValue() > maxGripStrengthPoint.getValue()){
                maxGripStrengthPoint = tempGripStrength;
            }
        }

        /**
         *  10% 악력값(Scalar) 구하기
         *  10% Max Out Valtage
         */
        tenGripStrengthValue = maxGripStrengthPoint.getValue() * 0.1F;


        /**
         *  10% 시작 악력점(Point)
         */
        iterator = gripStrengthList.listIterator();
        while (iterator.hasNext()) {
            GripStrength tempGripStrength = iterator.next();
            if(tempGripStrength.getValue() >= tenGripStrengthValue){
                tenGripStrengthStartPoint = tempGripStrength;
                break;
            }
        }

        /**
         *  10% 종료 악력점(Point)
         */
        iterator = gripStrengthList.listIterator(gripStrengthList.size());
        while (iterator.hasPrevious()) {
            GripStrength tempGripStrength = iterator.previous();
            if(tempGripStrength.getValue() >= tenGripStrengthValue){
                tenGripStrengthEndPoint = tempGripStrength;
                break;
            }
        }

        /**
         *  누적 악력값 구하기
         *  평균 악력값(Scalar) 구하기
         *  10% 시작 악력점(Point)와 10% 종료 악력점(Point) 구간의 평균값을 산정
         */
        double sumValue = 0.0;
        int count = 0;

        for(int i = gripStrengthList.indexOf(tenGripStrengthStartPoint); i <= gripStrengthList.indexOf(tenGripStrengthEndPoint); i++){
            if (gripStrengthList.get(i).getValue() > 0) {
                sumValue += gripStrengthList.get(i).getValue();
                count++;
            }
        }

        cumlativeSumValue = sumValue;

        if (count == 0){
            averageGripStrengthValue = 0.0;
        } else {
            averageGripStrengthValue = sumValue / count;
        }

        /**
         *  분산 
         *  10% 시작 악력점(Point)와 10% 종료 악력점(Point) 구간의 분산
         */
        double  sumVariance = 0.0;
        count = 0;
        for(int i = gripStrengthList.indexOf(tenGripStrengthStartPoint); i <= gripStrengthList.indexOf(tenGripStrengthEndPoint); i++){
            if (gripStrengthList.get(i).getValue() > 0) {
                float temp = gripStrengthList.get(i).getValue();
                sumVariance += Math.pow( (temp - averageGripStrengthValue), 2 );
                count++;
            }
        }
        varianGripStrengthValue =  sumVariance/count;

        /**
         *  표준편차
         *  10% 시작 악력점(Point)와 10% 종료 악력점(Point) 구간의 표준편차
         *  */
        sdGripStrengthValue = Math.sqrt( varianGripStrengthValue );

        printResult();
        parameter2.setParameterList(cumlativeSumValue, averageGripStrengthValue, varianGripStrengthValue, sdGripStrengthValue);
        parameter2.setInfomation( user, hand, finger, mobile);
        return true;
    }

    public void printResult(){
        System.out.println("--------------"+this.hand +"'"+ this.finger+" Information---------------");
        System.out.println("[개별]10% 시작(start) 악력값[값 : "+ tenGripStrengthValue +"]");
        System.out.println("[개별]10% 종료(end) 악력값[값 : "+ tenGripStrengthEndPoint +"]");
        System.out.println("[P1]Cumulative Sum[값 : "+ cumlativeSumValue +"]");
        System.out.println("[P2]평균 악력값[값 : "+ averageGripStrengthValue +"]");
        System.out.println("[P3]분산[값 : "+ varianGripStrengthValue +"]");
        System.out.println("[P4]표준편차[값 : "+ sdGripStrengthValue +"]");
    }

    public void saveParamCsv(){
        String fileName = user+"_"+ hand+"_" + mobile+"_"+"param2"+".csv";
        OutputStreamWriter bufferedWriter = null;
        FileOutputStream fileOutStrm = null;

        try {
            fileOutStrm = new FileOutputStream(fileName,true);
            bufferedWriter = new OutputStreamWriter( fileOutStrm, "MS949");
            //bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "MS949"));

            bufferedWriter.write("["+this.hand +"'"+ this.finger+"Key Parameter]"); bufferedWriter.write("\n");
            bufferedWriter.write("Contents" + "," + "Value" ); bufferedWriter.write("\n");
            bufferedWriter.write("[P1]Cumulative Sum[값 "+","+ cumlativeSumValue); bufferedWriter.write("\n");
            bufferedWriter.write("[P2]평균 악력[값 "+ "," + averageGripStrengthValue ); bufferedWriter.write("\n");
            bufferedWriter.write("[P3]분산[값 "+ "," + varianGripStrengthValue ); bufferedWriter.write("\n");
            bufferedWriter.write("[P4]표준편차[값 "+ "," + sdGripStrengthValue ); bufferedWriter.write("\n");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.flush(); // 남아있는 데이터까지 보내 준다
                    bufferedWriter.close(); // 사용한 BufferedWriter를 닫아 준다
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}






















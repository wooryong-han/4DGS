package com.artimesia.dynamometer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.ListIterator;

public class Solver4{
    private String finger; //손가락 지정
    private String user;   //사용자 이름
    private String hand;   //좌,우
    private String mobile; //핸폰

    private Param[] rightParam;
    private Param[] leftParam;

    private Parameter4 P4;

    public Solver4( Param[] rightParam, Param[] leftParam, Parameter4 P4) {
        this.rightParam=rightParam;
        this.leftParam=leftParam;
        this.P4 = P4;
    }

    public boolean analyse() {
        matchRateIndex( (Parameter2) rightParam[0], (Parameter2) leftParam[0]);
        matchRateMiddle( (Parameter2) rightParam[1], (Parameter2) leftParam[1]);
        matchRateRing( (Parameter2) rightParam[2], (Parameter2) leftParam[2]);
        matchRateLittle( (Parameter2) rightParam[2], (Parameter2) leftParam[2]);

        matchRateTotal( (Parameter3) rightParam[3], (Parameter3) leftParam[3] );
        return true;
    }

    public void matchRateIndex( Parameter2 rightP2, Parameter2 leftP2 )
    {
        double sum = matchRate( rightP2.getCumlativeSumValue(), leftP2.getCumlativeSumValue() );
        double avr = matchRate( rightP2.getAvr(), leftP2.getAvr() );
        double varian = matchRate( rightP2.getVarianValue(), leftP2.getVarianValue());
        double sd = matchRate( rightP2.getSd(), leftP2.getSd() );

        P4.setIndexMatchRate( sum, avr, varian, sd);
    }

    public void matchRateMiddle( Parameter2 rightP2, Parameter2 leftP2 )
    {
        double sum = matchRate( rightP2.getCumlativeSumValue(), leftP2.getCumlativeSumValue() );
        double avr = matchRate( rightP2.getAvr(), leftP2.getAvr() );
        double varian = matchRate( rightP2.getVarianValue(), leftP2.getVarianValue());
        double sd = matchRate( rightP2.getSd(), leftP2.getSd() );

        P4.setMiddleMatchRate( sum, avr, varian, sd);
    }

    public void matchRateRing( Parameter2 rightP2, Parameter2 leftP2 )
    {
        double sum = matchRate( rightP2.getCumlativeSumValue(), leftP2.getCumlativeSumValue() );
        double avr = matchRate( rightP2.getAvr(), leftP2.getAvr() );
        double varian = matchRate( rightP2.getVarianValue(), leftP2.getVarianValue());
        double sd = matchRate( rightP2.getSd(), leftP2.getSd() );

        P4.setRingMatchRate( sum, avr, varian, sd);
    }

    public void matchRateLittle( Parameter2 rightP2, Parameter2 leftP2 )
    {
        double sum = matchRate( rightP2.getCumlativeSumValue(), leftP2.getCumlativeSumValue() );
        double avr = matchRate( rightP2.getAvr(), leftP2.getAvr() );
        double varian = matchRate( rightP2.getVarianValue(), leftP2.getVarianValue());
        double sd = matchRate( rightP2.getSd(), leftP2.getSd() );

        P4.setLittleMatchRate( sum, avr, varian, sd);
    }

    public void matchRateTotal( Parameter3 rightP3, Parameter3 leftP3 )
    {
        double sum = matchRate( rightP3.getCumlativeSumValue(), leftP3.getCumlativeSumValue() );
        double avr = matchRate( rightP3.getAvr(), leftP3.getAvr() );
        double varian = matchRate( rightP3.getVarianValue(), leftP3.getVarianValue());
        double sd = matchRate( rightP3.getSd(), leftP3.getSd() );

        P4.setTotalMatchRate( sum, avr, varian, sd);
    }

    double matchRate( double right, double left )
    {
        double result = 100 - (((right-left)/(right)) * 100);
        return result;
    }

    public void printResult(){
        /*
        System.out.println("---------------------"+this.name+" Information---------------------");
        System.out.println("[P1]최대 악력점[시간 : " +maxGripStrengthPoint.getMillisecond()+", 값 : "+maxGripStrengthPoint.getValue() +"]");
        System.out.println("[P2]90% 악력값[값 : "+ ninetyGripStrengthValue +"]");
        System.out.println("[P3]10% 악력값[값 : "+ tenGripStrengthValue +"]");
        System.out.println("[P4]평균 악력값[값 : "+ averageGripStrengthValue +"]");
        System.out.println("[P5]90% 시작 악력점[시간 : " +ninetyGripStrengthStartPoint.getMillisecond()+", 값 : "+ninetyGripStrengthStartPoint.getValue() +"]");
        System.out.println("[P6]90% 종료 악력점[시간 : " +ninetyGripStrengthEndPoint.getMillisecond()+", 값 : "+ninetyGripStrengthEndPoint.getValue() +"]");
        System.out.println("[P7]10% 시작 악력점[시간 : " +tenGripStrengthStartPoint.getMillisecond()+", 값 : "+tenGripStrengthStartPoint.getValue() +"]");
        System.out.println("[P8]10% 종료 악력점[시간 : " +tenGripStrengthEndPoint.getMillisecond()+", 값 : "+tenGripStrengthEndPoint.getValue() +"]");
        System.out.println("[P9]평균 시작 악력점[시간 : " +averageGripStrengthStartPoint.getMillisecond()+", 값 : "+averageGripStrengthStartPoint.getValue() +"]");
        System.out.println("[P10]평균 종료 악력점[시간 : " +averageGripStrengthEndPoint.getMillisecond()+", 값 : "+averageGripStrengthEndPoint.getValue() +"]");
        System.out.println("[P11]측정 시간 간격[시간 : "+ measureInterval +"]");
        System.out.println("[P12]시작(Start) 시간[시간 : "+ startTime +"]");
        System.out.println("[P13]종료(End) 시간[시간 : "+ endTime +"]");
        System.out.println("[P14]온셋(Onset) 시간 간격[시간 : "+ onsetInterval +"]");
        System.out.println("[P15]지속(Endurance) 시간 간격[시간 : "+ enduranceInterval +"]");
        System.out.println("[P16]소산(Dissipate) 시간 간격[시간 : "+ dissipateInterval +"]");
        System.out.println("[P17]10% 시작 악력점이 나타나는 시간 간격[시간 : "+ tenGripStrengthStartInterval +"]");
        System.out.println("[P18]평균 시작 악력점이 나타나는 시간 간격[시간 "+ averageGripStrengthStartInterval +"]");
        System.out.println("[P19]90% 시작 악력점이 나타나는 시간 간격[시간 : "+ ninetyGripStrengthStartInterval +"]");
        System.out.println("[P20]최대 악력점이 나타나는 시간 간격[시간 : "+ maxGripStrengthInterval +"]");
        System.out.println("[P21]평균 종료 악력점이 나타나는 시간 간격[시간 "+ averageGripStrengthEndInterval +"]");
        */
    }

}

package com.artimesia.dynamometer;


/*
 * 손가락별 데이터 구조
 * 1. 연속적인 데이터 합
 * 2. 평균, 분산, 표준편차
 *
 */

public class Parameter2 extends Param{
}

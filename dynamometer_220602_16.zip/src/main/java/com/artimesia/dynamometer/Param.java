package com.artimesia.dynamometer;

public class Param{
    public String desc = "";
}

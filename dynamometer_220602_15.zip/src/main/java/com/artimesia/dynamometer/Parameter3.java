package com.artimesia.dynamometer;

/*
 * 측정 위치별
 * 1. 시간별 Index, Middle, Ring, Little  데이터 합
 * 2. 시간별 Index, Middle, Ring, Little 가각 평균, 분산, 표준편차
 *
 */

public class Parameter3 extends Param{
}

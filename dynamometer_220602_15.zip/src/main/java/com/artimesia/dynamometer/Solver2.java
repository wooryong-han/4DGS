package com.artimesia.dynamometer;

import java.util.ArrayList;
import java.util.ListIterator;

/**
 * solver2
 * 측정 위치 기준
 * 손가락별 연속적인 데이터 합
 * 손가락별 평균, 분산, 표준편차
 * 시간별 손가락별 합력(전체합)
 * 시간별 평균, 분산, 표준편차
 */

public class Solver2 {
    private Parameter2 parameter;
    private float CumlativeSum = 0.0f;  //연속적인 누적합
    private ArrayList<GripStrength> gripStrengthList;

    private String name; //손가락 지정
    private String user; //사용자 이름
    private String hand; //좌,우
    private String mobile; //핸폰

    public Solver2(String name, ArrayList<GripStrength> gripStrengthList, String user, String hand, String mobile, Parameter2 parameter) {
        // 손가락 지정
        this.name = name;
        // 악력값 리스트 받기
        this.gripStrengthList = gripStrengthList;

        this.user = user;
        this.hand = hand;
        this.mobile = mobile;
        this.parameter = parameter;
    }

    public boolean analyse() {
        ListIterator<GripStrength> iterator = gripStrengthList.listIterator();

        /**
         *  손가락별 누적합
         */
        iterator = gripStrengthList.listIterator();
        while (iterator.hasNext()) {
            GripStrength tempGripStrength = iterator.next();

            //if(tempGripStrength.getValue() >= averageGripStrengthValue){
            //    averageGripStrengthStartPoint = tempGripStrength;
            //    break;
            //}
        }
        return true;
    }
}

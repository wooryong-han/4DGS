
package com.artimesia.dynamometer;

/*
 * 1. Parameter4 용
 * 2. right Hand 클래스에 손가락별 파라메터 p1,p2,p3
 * 3. left Hand 클래스에 손가락별 파라메터 p1,p2,p3
 * 4. 일치도
 */

public class Solver3 {

    //Inner Class
    //Hand
}

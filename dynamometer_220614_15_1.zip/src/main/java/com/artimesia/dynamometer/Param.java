package com.artimesia.dynamometer;

public class Param{
    public String desc = "";

    protected String user;    //사용자 이름
    protected String hand;    //좌,우
    protected String finger;  //손가락 지정
    protected String mobile;  //핸폰
}

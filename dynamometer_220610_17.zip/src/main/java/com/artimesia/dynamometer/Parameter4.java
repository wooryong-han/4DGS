package com.artimesia.dynamometer;

import java.util.ArrayList;

/*
 * 1. 오른손/왼손 손가락별 좌우 누적합의 일치도 -> parameter2 사용
 * 2. 오른손/왼손 손가락별 좌우 평균/분산/표준편차 일치도 -> parameter2 사용
 * 3. 오른손/왼손 시간별 손가락 합력에 대한 일치도 -> parameter3 사용
 * 4. 오른손/왼손 시간별 손가락 합력에 대한 평균, 분산, 표준편차  -> parameter3 사용
 */

public class Parameter4 extends Param{
    private Param[] rightParam = new Param[5];
    private Param[] leftParam = new Param[5];

    //손가락별 좌우 누적합의 일치도
    private double indexSumCCDRate = 0.0;
    private double middleSumCCDRate = 0.0;
    private double ringSumCCDRate = 0.0;
    private double littleSumCCDRate = 0.0;

    //손가락별 좌우 평균의 일치도
    private double indexAvgCCDRate = 0.0;
    private double middleAvgCCDRate = 0.0;
    private double ringAvgCCDRate = 0.0;
    private double littleAvgCCDRate = 0.0;

    //손가락별 좌우 분산 일치도
    private double indexVarianCCDRate = 0.0;
    private double middleVarianCCDRate = 0.0;
    private double ringVarianCCDRate = 0.0;
    private double littleVarianCCDRate = 0.0;

    //손가락별 좌우 표준편차 일치도
    private double indexSDCCDRate = 0.0;
    private double middleSDCCDRate = 0.0;
    private double ringSDCCDRate = 0.0;
    private double littleSDCCDRate = 0.0;

    //합력 시간별 일치도
    private double fingerSumCCDRate = 0.0;  //시간별 손가락 합력의 일치도
    private double fingerAvgCCDRate = 0.0;   //시간별 손가락 평균의 일치도
    private double fingerVarianCCDRate = 0.0;  //시간별 손가락 분산의 일치도
    private double fingerSDCCDRate = 0.0;   //시간별 손가락 표준편차 일치도

    public Parameter4(){
    }

    public void setParamList(String hand, Parameter2 indexP2, Parameter2 middleP2, Parameter2 ringP2, Parameter2 littleP2, Parameter3 P3) {
        if( "RIGHT" == hand ) {
            rightParam[0] = indexP2;
            rightParam[1] = middleP2;
            rightParam[2] = ringP2;
            rightParam[3] = littleP2;
            rightParam[4] = P3;
        }else {
            leftParam[0] = indexP2;
            leftParam[1] = middleP2;
            leftParam[2] = ringP2;
            leftParam[3] = littleP2;
            leftParam[4] = P3;
        }
    }
}

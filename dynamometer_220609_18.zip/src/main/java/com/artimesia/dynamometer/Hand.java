package com.artimesia.dynamometer;

import java.util.ArrayList;

public class Hand {
    private String handLocation;

    private ArrayList<Param> indexParamList = new ArrayList<>(); //index p1, p2, p3
    private ArrayList<Param> middleParamList = new ArrayList<>();//middle p1, p2, p3
    private ArrayList<Param> ringParamList = new ArrayList<>();//ring p1, p2, p3
    private ArrayList<Param> littleParamList = new ArrayList<>();//little p1, p2, p3

    public Hand(String handLocation) {
        this.handLocation = handLocation;

    }


}

package com.artimesia.dynamometer;

/*
 *
 * 1. 오른손/왼손 손가락별 좌우 합의 일치도 -> parameter2 사용
 * 2. 오른손/왼손 손가락별 좌우 평균/분산/표준편차 일치도 -> parameter2 사용
 * 3. 오른손/왼손 시간별 손가락 합력에 대한 일치도 -> parameter3 사용
 * 4. 오른손/왼손 시간별 손가락 합력에 대한 평균, 분산, 표준편차  -> parameter3 사용
 *
 */
public class Parameter4 extends Param{
}
